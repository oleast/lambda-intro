def hello(event, context):
  print("Hei folkens!")
  return "Hei folkens!"

if __name__ == '__main__':
  hello()
