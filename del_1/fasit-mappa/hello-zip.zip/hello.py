def hello(event, context):
    return "Hei folkens!"


if __name__ == "__main__":
    hello()
